from django import forms
from .models import *


class Todo_form(forms.Form):
    class Meta:
        models=Todolist
        fields='__all__'