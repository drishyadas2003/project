from django.shortcuts import render
from .models import *
from .forms import *

# Create your views here.
def index(request):
     todo=Todolist.objects.all()
     form_obj=Todo_form()
     if request.method=="POST":
          if 'delete' in request.POST:
               key=request.POST.get('delete')
               a=Todolist.objects.get(id=key)
               a.delete()
          


                         
     context={}
     context['todo']=todo
     context['form_obj']=form_obj

     return render(request,'index.html',context)
